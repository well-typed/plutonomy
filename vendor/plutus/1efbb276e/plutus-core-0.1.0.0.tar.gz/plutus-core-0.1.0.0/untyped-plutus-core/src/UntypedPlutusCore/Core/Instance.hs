module UntypedPlutusCore.Core.Instance (module Export) where

import           UntypedPlutusCore.Core.Instance.Eq        as Export
import           UntypedPlutusCore.Core.Instance.Pretty    ()
import           UntypedPlutusCore.Core.Instance.Recursive as Export
