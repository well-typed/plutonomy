module PlutusIR.Core (module Export) where

import           PlutusIR.Core.Instance ()
import           PlutusIR.Core.Plated   as Export
import           PlutusIR.Core.Type     as Export
