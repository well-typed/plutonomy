-- | A module alias for way too verbose "Prettyprinter".
module Text.Pretty
    ( module Export
    ) where

import Prettyprinter as Export
